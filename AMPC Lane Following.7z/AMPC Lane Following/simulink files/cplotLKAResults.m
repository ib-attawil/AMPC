function cplotLKAResults(scenario,driverPath,x,y)

plotDriverPath = true;
if nargin < 3
    plotDriverPath = false;
end
% Overlay driver path and actual path
figure('Color','white');
ax1 = subplot(1,1,1);


plot(scenario,'Parent',ax1)
ylim([-500 2000])



if plotDriverPath
    line(ax1,driverPath(:,1),driverPath(:,2),'Color','blue','LineWidth',1)
  
    ax1.Title = text(0.5,0.5,'Road and driver path');
   
else
    ax1.Title = text(0.5,0.5,'Road and assisted path');
   
end

line(ax1,x(:,1),...
     y(:,1),...
     'Color','red','LineWidth',1)
